$(document).ready(function() {
    "use strict";
    App.ui.mostrarInicio();
    App.data.conseguirJSON();

});